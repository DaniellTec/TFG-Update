# Navbar

A fully responsive and reusable header / navbar component built with React.

## CodeFocus Channel

This project's build walkthrough video can be accessed on the CodeFocus youtube channel. Heres a link:

### `npm start`

Runs the app in the development mode.
Open http://localhost:3000 to view it in the browser.

The page will reload if you make edits.
You will also see any lint errors in the console.

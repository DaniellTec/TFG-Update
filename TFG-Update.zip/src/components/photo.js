function Photo() {
    document.getElementById("demo").innerHTML = "Hello World";
  }